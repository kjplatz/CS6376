
// File Name :    OpenMp.c
// Course:        CS 6376 Spring 2017
// Author:        Rachna Sidana
// Assignment:    Program 3 - Part 1
// Description:   This program applies openMp directives to the Floyd Warshall Algorithm and 
//                calculates the execution time of code that has been parallelized.

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <math.h>
void Init_matrix(int** mat, int n);
void Print_matrix(int** mat, int n);
void Floyd(int** mat, int n);

int main(void) {
int n;
struct timeval start_time, stop_time, elapsed_time;  // timers
double  numFlops;
float gflops;
printf("How many vertices?\n");
scanf("%d", &n);
int *arr[n];
for (int i=0; i<n; i++)
   arr[i] = (int *)malloc(n * sizeof(int));
Init_matrix(arr, n);   
gettimeofday(&start_time,NULL);
Floyd(arr, n);
gettimeofday(&stop_time,NULL);
timersub(&stop_time, &start_time, &elapsed_time); // Unix time subtract routine
printf("Total time was %f seconds.\n", elapsed_time.tv_sec+elapsed_time.tv_usec/1000000.0);
numFlops = 2.0f*n*n*n/1000000000.0f;
gflops = numFlops/(elapsed_time.tv_sec+elapsed_time.tv_usec/1000000.0);
printf("GFlops :  %f .\n",gflops); 
return 0;
}  

/*-------------------------------------------------------------------
 * Function:  Init_matrix
 * Purpose:   initialize the adjacency matrix
 ------------------------------------------------------------------*/
void Init_matrix(int** mat, int n) {
   int i, j,val;
	int INFINTY=n-1;
   for (i = 0; i < n; i++) {
      for (j = 0; j < n; j++)
         if (i == j)
            mat[i][j]=0;
         else {
            if ((i==j+1)|| (j==i+1)||((i==0)&&(j==n-1))||((i==n-1)&&(j==0)))
               mat[i][j]=1;
            else
               mat[i][j]= n;
         }
   }

}  

/*-------------------------------------------------------------------
 * Function:  Print_matrix
 * Purpose:   Print the contents of the matrix
 -----------------------------------------------------------------*/
void Print_matrix(int**  mat, int n) {
   int i, j;

   for (i = 0; i < n; i++) {
      for (j = 0; j < n; j++)
            printf("%d ", mat[i][j]);
      printf("\n");
   }
}  

/*-------------------------------------------------------------------
 * Function:    Floyd
 * Purpose:     Apply Floyd's algorithm to the matrix mat
 ----------------------------------------------------------------------*/
void Floyd(int**  mat, int n) {
   int k, i, j;
   for (k = 0; k < n; k++) {
      #pragma omp parallel for private(i,j) shared( mat, k)
	for (i = 0; i < n; i++)
         for (j = 0; j < n; j++) {
                 mat[i][j] =fmin(mat[i][j], mat[i][k] + mat[k][j]);
         }
   }
}  

