CS 6376.001 - Parallel Processing
Program 4 - Matrix Multiplication
Tarunesh Verma (txv140330)

Description of Contents
========================

1. pgm1_complete/
------------------
Directory containing the parallelized codes.
The folder for MPI contains batch script and the generated output files.
	Due to massive matrix sizes, only job slurm-931861 (16K x 16K) completed
	within the regular time limit specified by Bridges. The rest of the output
	files have incomplete outputs (please refer to the attached report for more
	information. )

2. README.txt
--------------
This file.

3. Report - Tarunesh Verma (txv140330).pdf
-------------------------------------------
A report containing Problem Description, Approach to Solution, and Solution Description.