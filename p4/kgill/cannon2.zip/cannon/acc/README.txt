Make number of cores 28 in that fucking thing.
