# cannon
Cannon's algorithm for matrix multiplication. 

Use Makefile to compile, ./cannon.out to execute.
